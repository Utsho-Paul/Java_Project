public class UtshoCash extends OnlineBanking{

    void displayManu()
    {

        System.out.println("***************UP Cash*************");
        System.out.println("___________________________________________________");
        System.out.println("1.Send Money");
        System.out.println("2.Mobile Recharge");
        System.out.println("3.Payment");
        System.out.println("4.Cash In");
        System.out.println("5.Cash Out");
        System.out.println("6.Check Balance:");
        System.out.println("7.Help Line");
    }
}
