import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        float amount = 1000.00f;
        while (true) {
        System.out.println("Enter the Number: ");
        Scanner sc = new Scanner(System.in);
        String n = sc.nextLine();
        System.out.println("Enter the Password: ");
        int p = sc.nextInt();
        UtshoCash c1 = new UtshoCash();
        c1.setMobileNumber("0");
        c1.setPassword(22222);
           String x = c1.getMobileNumber();
           int y = c1.getPassword();


        int s=(n.compareTo(x));
        if(s==0 && p==y) {
            UtshoCash u2 = new UtshoCash();
            u2.displayManu();
            System.out.println("Enter Your Choice? ");
                Scanner vc = new Scanner(System.in);
                int c = vc.nextInt();
                if (c == 1) {
                    System.out.println("Enter Receiver UP Cash Acount Number: ");
                    String user = vc.next();
                    System.out.println("Amount: ");
                    int am = vc.nextInt();
                    System.out.println("Refarance: ");
                    int re = vc.nextInt();
                    System.out.println("Enter your pin");
                    int pi = vc.nextInt();
                    if (pi == 22222) {
                        if(amount>=am) {
                            System.out.println("successfully Send Money");

                            System.out.println("Your Current blance is : "+ (amount-am));
                        }
                        else
                        {
                            System.out.println("Not Enoughp Blance!Sorry");
                        }
                    } else {
                        System.out.println("invalid password");
                    }
                    amount = amount-am;
                } else if (c == 2) {
                    System.out.println("1.Robi");
                    System.out.println("2.Airtel");
                    System.out.println("3.Banglaink");
                    System.out.println("4.Grameenphone");
                    System.out.println("5.Teletalk");
                    System.out.println("Enter Selectted Opertar: ");
                    int ax = vc.nextInt();
                    System.out.println("Enter the Number:");
                    String num = vc.next();
                    System.out.println("Enter the Amount: ");
                    int aa = vc.nextInt();
                    System.out.println("Pin Number: ");
                    int p1 = vc.nextInt();
                    if (p1 == 22222) {
                        if (amount > aa)
                            System.out.println("Mobile Recharge Succersful");
                        System.out.println("Blance: " + (amount - aa));
                    } else {
                        System.out.println("Invalid");
                    }
                    amount = amount-aa;
                } else if (c == 3) {
                    System.out.println("Enter Merchant Account Number: ");
                    String pay = vc.next();
                    System.out.println("Amount: ");
                    int amo = vc.nextInt();
                    System.out.println("Pin Number:");
                    int pp = vc.nextInt();
                    if (pp == 22222) {
                        if (amount > amo) {
                            System.out.println("Payment Successful");
                            System.out.println("The current balance on your account " + (amount - amo) + "Tk");
                        } else {
                            System.out.println("Not Enoughp Blance");
                        }
                    } else {
                        System.out.println("Worng password");
                    }
                    amount = amount-amo;
                } else if (c == 4) {
                    System.out.println("Enter Cash In Amount : ");
                    int aaa = vc.nextInt();
                    System.out.println("Cash in Successful");
                    System.out.println("The current balance on your account: " + (aaa + amount));
                    amount = amount+aaa;
                } else if (c == 5) {
                    System.out.println("Enter Agent Number: ");
                    String agent = vc.next();
                    System.out.println("Enter CashOut Amount: ");
                    float aaaa = vc.nextFloat();
                    System.out.println("Enter Password: ");
                    int ppa = vc.nextInt();
                    if (ppa == 22222) {
                        float xy = aaaa * 0.008f;

                        if (aaaa + xy <= amount) {
                            System.out.println("CashOut Syccessful");
                            System.out.println("The current balance on your account: " + (amount - (aaaa + xy)));
                        } else {
                            System.out.println("Not enoughp Blance");
                        }
                        amount = amount - (aaaa + xy);

                    }
                    else
                    {
                        System.out.println("Invalid password");
                    }
                }

                    else if (c == 6) {
                    System.out.println("The current balance on your account is: " + amount);
                } else if (c == 7) {
                    System.out.println("Welcome To Up Cash ");
                    System.out.println("Help Line: 299");
                }
                else
                {
                    break;
                }
            }
        else
        {
            OnlineBanking n1  = new OnlineBanking();
            n1.displayManu();
        }
        }
        }
}

