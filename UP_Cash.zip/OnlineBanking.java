public class OnlineBanking {
    private String mobileNumber;
    private int password;

    public String getMobileNumber() {

        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {

        this.mobileNumber = mobileNumber;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }
void displayManu()
{
    System.out.println("invalid password");
}
}
